## Plano de Alterações Visuais

### 1. Fundo branco (voltar ao tema claro)
**Arquivo:** `src/App.tsx`
- Mudar `forcedTheme="dark"` e `defaultTheme="dark"` para `defaultTheme="light"` e `forcedTheme="light"`, garantindo que toda a aplicação use as cores do tema claro definidas em `index.css` (fundo branco, texto preto).

### 2. Header preto
**Arquivo:** `src/components/Header.tsx`
- Adicionar classes para forçar o header com fundo preto e texto/links em branco, independente do tema:
  - Container: `bg-black` (com `bg-black/95 backdrop-blur` quando rolar)
  - Logo "JC": texto branco
  - Links de navegação: texto branco com hover em cinza claro
  - Ícone Home: branco
  - Botão "Fale Comigo": fundo branco, texto preto (para contraste com o header preto)
  - Menu mobile: mesmas cores

### 3. Renomear seção "Experiência"
**Arquivo:** `src/components/Header.tsx`
- No array `navItems`, mudar `label: "Experiência"` para `label: "Experiências"`.

### 4. Renomear título "Profissional"
**Arquivo:** `src/components/Experience.tsx`
- Alterar o `<h2>` de `"Profissional"` para `"Minhas experiências profissionais"`.

### 5. Remover animação do botão "Fale Comigo"
**Arquivo:** `src/components/Header.tsx`
- Remover a classe `animate-glow-pulse` dos dois botões "Fale Comigo" (desktop e mobile).
- Manter apenas a transição de hover padrão.

---

### Observação / Dúvida
Atualmente todos os cards e seções foram pensados para o modo escuro (foi o último ajuste feito). Como os componentes já usam tokens semânticos (`bg-background`, `text-foreground`, `bg-card`, etc.), ao voltar para o tema claro **todas as seções voltam automaticamente para branco com texto preto** — o que é o efeito desejado.

O único ponto que **não usa tokens semânticos** será o header, que ficará preto fixo via classes utilitárias diretas (`bg-black`, `text-white`), conforme você pediu.

Se preferir um preto menos absoluto (ex: cinza escuro `#0a0a0a`) ou um header com leve transparência, me avise antes de implementar.