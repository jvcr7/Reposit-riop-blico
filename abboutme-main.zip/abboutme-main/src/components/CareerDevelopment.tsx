import { GlowCard } from "@/components/ui/spotlight-card";

const goals = [
  {
    title: "Curto Prazo",
    items: [
      "Concluir primeira graduação em administração de empresas",
      "Ingressar como analista no mercado financeiro",
      "Aprofundar conhecimentos em IA aplicada e engenharia de dados",
      "Obter certificações financeiras (CPA-20 e CEA)"
    ],
    glowColor: "blue" as const
  },
  {
    title: "Médio Prazo",
    items: [
      "Iniciar especialização em temas econômicos",
      "Realizar intercâmbio estudantil",
      "Estar qualificado para liderar projetos de transformação digital"
    ],
    glowColor: "purple" as const
  },
  {
    title: "Longo Prazo",
    items: [
      "Construir/Liderar projetos estratégicos",
      "Ter qualificação para mentorar novos profissionais"
    ],
    glowColor: "green" as const
  }
];

const CareerDevelopment = () => {
  return (
    <section id="carreira" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl md:text-5xl font-bold mb-16 text-center text-black">
          Planejamento de Carreira
        </h2>
        
        <div className="max-w-6xl mx-auto grid md:grid-cols-3 gap-8">
          {goals.map((goal, index) => (
            <GlowCard 
              key={index}
              glowColor={goal.glowColor}
              customSize={true}
              className="p-8 hover:-translate-y-2 transition-all duration-300 ease-out cursor-pointer animate-fade-in-up"
            >
              <div className="flex flex-col h-full">
                <h3 className="text-2xl font-bold mb-6 text-foreground">{goal.title}</h3>
                
                <ul className="space-y-3">
                  {goal.items.map((item, i) => (
                    <li key={i} className="text-muted-foreground">
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </GlowCard>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CareerDevelopment;
