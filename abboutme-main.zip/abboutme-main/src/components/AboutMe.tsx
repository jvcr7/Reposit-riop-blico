import { Card, CardContent } from "@/components/ui/card";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import Autoplay from "embla-carousel-autoplay";

const AboutMe = () => {
  const photos = [
    { id: 1, title: "", image: "/placeholder.svg" },
    { id: 2, title: "", image: "/placeholder.svg" },
    { id: 3, title: "", image: "/placeholder.svg" },
    { id: 4, title: "", image: "/placeholder.svg" },
  ];

  return (
    <section id="sobre-mim" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        {/* Texto introdutório centralizado */}
        <p className="text-xl font-semibold text-black mb-12 max-w-4xl mx-auto text-center">
          Por trás de cada trajetória profissional, existe uma história pessoal
        </p>

        {/* Carrossel */}
        <Carousel
          opts={{
            loop: true,
            align: "start",
          }}
          plugins={[
            Autoplay({
              delay: 4000,
            }),
          ]}
          className="w-full max-w-6xl mx-auto"
        >
          <CarouselContent>
            {photos.map((photo) => (
              <CarouselItem key={photo.id} className="md:basis-1/2 lg:basis-1/3">
                <div className="p-1">
                  <Card className="overflow-hidden hover:shadow-hover transition-all duration-300">
                    <CardContent className="p-0">
                      <AspectRatio ratio={16 / 9}>
                        <img
                          src={photo.image}
                          alt={photo.title}
                          className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                        />
                      </AspectRatio>
                      <div className="p-4">
                        <h3 className="font-semibold text-lg text-foreground">
                          {photo.title}
                        </h3>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>
          <CarouselPrevious />
          <CarouselNext />
        </Carousel>
      </div>
    </section>
  );
};

export default AboutMe;
