import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Menu, X, Home } from "lucide-react";

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
      setIsMobileMenuOpen(false);
    }
  };

  const navItems = [
    { label: "Sobre mim", id: "sobre-mim" },
    { label: "Formação", id: "formacao" },
    { label: "Experiências", id: "experiencias" },
    { label: "Planejamento de Carreira", id: "carreira" },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? "bg-white/95 backdrop-blur-lg shadow-md" : "bg-white"
      }`}
    >
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <button
            onClick={() => scrollToSection("hero")}
            className="text-2xl font-bold text-black hover:opacity-80 transition-all duration-300 hover:scale-105"
          >
            JC
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className="text-black hover:text-gray-600 transition-all duration-500 relative group font-medium hover:scale-110"
              >
                {item.label}
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-black group-hover:w-full transition-all duration-500" />
              </button>
            ))}
            <button
              onClick={() => scrollToSection("hero")}
              className="p-2 rounded-md hover:bg-black/10 text-black transition-all duration-300"
              aria-label="Ir para início"
            >
              <Home size={20} />
            </button>
            <Button
              onClick={() => scrollToSection("contato")}
              className="bg-black text-white hover:bg-gray-800 transition-colors duration-300"
            >
              Fale Comigo
            </Button>
          </nav>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center gap-2">
            <button
              onClick={() => scrollToSection("hero")}
              className="p-2 rounded-md hover:bg-black/10 text-black transition-all duration-300"
              aria-label="Ir para início"
            >
              <Home size={20} />
            </button>
            
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-black"
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <nav className="md:hidden mt-6 pb-6 flex flex-col gap-6 animate-fade-in">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className="text-black hover:text-gray-600 transition-all duration-500 text-left font-medium hover:translate-x-2"
              >
                {item.label}
              </button>
            ))}
            <Button
              onClick={() => scrollToSection("contato")}
              className="bg-black text-white hover:bg-gray-800 transition-colors duration-300 w-full"
            >
              Fale Comigo
            </Button>
          </nav>
        )}
      </div>
    </header>
  );
};

export default Header;
