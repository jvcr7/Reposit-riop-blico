import { useState, useEffect, useRef } from "react";
import { Award } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { GlowingEffect } from "@/components/ui/glowing-effect";
import saoJudasLogo from "@/assets/sao-judas-logo.png";
import utfprLogo from "@/assets/utfpr-logo.webp";
import pm3Logo from "@/assets/pm3-logo.png";
import hashtagLogo from "@/assets/hashtag-logo.jpeg";

interface EducationItem {
  title: string;
  institution: string;
  location?: string;
  period?: string;
  status?: string;
  type: "degree" | "certification";
  logo?: string;
  credential?: string;
  credentialUrl?: string;
}

const allEducation: EducationItem[] = [
  {
    title: "Bacharelado em Administração de Empresas",
    institution: "Universidade São Judas Tadeu",
    location: "São Paulo",
    period: "2022 – 2026",
    status: "Último semestre",
    type: "degree",
    logo: saoJudasLogo
  },
  {
    title: "Técnico em Administração de Empresas",
    institution: "Universidade Federal do Paraná",
    location: "Paraná",
    period: "2021 – 2022",
    status: "Concluído",
    type: "degree",
    logo: utfprLogo
  },
  {
    title: "Lovable and AI Automation Specialist",
    institution: "PM3",
    type: "certification",
    logo: pm3Logo,
    credential: "a7c4df2080be6535405ace4160e2e33e",
    credentialUrl: "https://gerarcertificado.com.br/validar.php"
  },
  {
    title: "Power BI Intermediário",
    institution: "Hashtag Treinamentos",
    type: "certification",
    logo: hashtagLogo
  },
  {
    title: "Comunicação Eficaz",
    institution: "Hashtag Treinamentos",
    type: "certification",
    logo: hashtagLogo
  }
];

const Education = () => {
  const [visibleCards, setVisibleCards] = useState<{ [key: number]: boolean }>({});
  const [scrollProgress, setScrollProgress] = useState<{ [key: number]: number }>({});
  const cardRefs = useRef<(HTMLDivElement | null)[]>([]);
  const sectionRef = useRef<HTMLDivElement | null>(null);

  // Intersection observer for visibility animation
  useEffect(() => {
    const observers: IntersectionObserver[] = [];

    cardRefs.current.forEach((ref, index) => {
      if (ref) {
        const observer = new IntersectionObserver(
          ([entry]) => {
            if (entry.isIntersecting) {
              setVisibleCards(prev => ({ ...prev, [index]: true }));
            }
          },
          { threshold: 0.2 }
        );
        observer.observe(ref);
        observers.push(observer);
      }
    });

    return () => {
      observers.forEach(observer => observer.disconnect());
    };
  }, []);

  // Scroll listener for progressive stacking effect
  useEffect(() => {
    const handleScroll = () => {
      cardRefs.current.forEach((ref, index) => {
        if (ref) {
          const rect = ref.getBoundingClientRect();
          const stickyTop = 100 + index * 40;
          // Calculate progress: 0 = far, 1 = fully sticky
          const distanceToSticky = rect.top - stickyTop;
          const progress = Math.min(1, Math.max(0, 1 - (distanceToSticky / 300)));
          setScrollProgress(prev => ({ ...prev, [index]: progress }));
        }
      });
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll(); // Initial calculation
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const getMarginBottom = (index: number) => {
    const progress = scrollProgress[index] ?? 0;
    return 60 * (1 - progress); // 60px → 0px
  };

  const getShadow = () => {
    return 'none';
  };

  const getScale = (index: number) => {
    const progress = scrollProgress[index] ?? 0;
    return 1 - progress * 0.02; // 1 → 0.98 (subtle scale down when stacked)
  };

  return (
    <section id="formacao" className="py-20 bg-card/50">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl md:text-5xl font-bold mb-16 text-center text-black">
          Acadêmico
        </h2>
        
        <div className="max-w-6xl mx-auto">
          {/* Unified Stacking Cards */}
          <div className="relative" ref={sectionRef}>
            {allEducation.map((item, index) => (
              <div
                key={index}
                ref={el => cardRefs.current[index] = el}
                className={`sticky transition-all duration-300 ${
                  visibleCards[index] 
                    ? 'opacity-100 translate-y-0' 
                    : 'opacity-0 translate-y-8'
                }`}
                style={{
                  top: `${100 + index * 40}px`,
                  zIndex: index + 1,
                  marginBottom: `${getMarginBottom(index)}px`,
                  boxShadow: getShadow(),
                  transform: `scale(${getScale(index)})`,
                }}
              >
                <div className="relative rounded-xl">
                  <GlowingEffect
                    spread={40}
                    glow={true}
                    disabled={false}
                    proximity={64}
                    inactiveZone={0.01}
                    borderWidth={2}
                  />
                  <Card className="relative p-6 md:p-8 bg-card border-border transition-all duration-300">
                  <div className="flex items-start gap-4">
                    {/* Logo/Icon */}
                    {item.logo ? (
                      <div className="w-12 h-12 rounded-lg overflow-hidden bg-white flex items-center justify-center shrink-0">
                        <img src={item.logo} alt={`${item.institution} logo`} className="w-full h-full object-contain p-1" />
                      </div>
                    ) : (
                      <div className="w-12 h-12 rounded-lg flex items-center justify-center shrink-0" style={{ backgroundColor: '#e5e7eb' }}>
                        <Award className="w-6 h-6" style={{ color: '#6b7280' }} />
                      </div>
                    )}
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-start justify-between gap-2 mb-2">
                        <h3 className="text-xl font-bold text-foreground">{item.title}</h3>
                        {/* Badge logic: Card 0 keeps "Último semestre", Cards 1-4 get green "Concluído" */}
                        {index === 0 && item.status === "Último semestre" && (
                          <span className="px-3 py-1 rounded-full text-xs font-semibold shrink-0 bg-accent/20 text-accent">
                            {item.status}
                          </span>
                        )}
                        {index > 0 && (
                          <span className="px-3 py-1 rounded-full text-xs font-semibold shrink-0 bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400">
                            Concluído
                          </span>
                        )}
                      </div>
                      <p className="text-lg text-muted-foreground mb-1">{item.institution}</p>
                      
                      {/* Location and Period for degrees */}
                      {item.type === "degree" && (
                        <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                          {item.location && <span>📍 {item.location}</span>}
                          {item.period && <span>📅 {item.period}</span>}
                        </div>
                      )}
                      
                      {/* Ver certificado button for all cards */}
                      <div className="mt-3">
                        {item.credentialUrl ? (
                          <Button variant="outline" size="sm" asChild>
                            <a 
                              href={item.credentialUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                            >
                              Ver certificado
                            </a>
                          </Button>
                        ) : (
                          <Button variant="outline" size="sm" disabled>
                            Ver certificado
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                  </Card>
                </div>
              </div>
            ))}
            {/* Spacer for scroll */}
            <div className="h-[400px]" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Education;
