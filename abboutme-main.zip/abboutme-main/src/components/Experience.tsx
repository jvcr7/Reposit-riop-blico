import { Calendar, CheckCircle2 } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Card } from "@/components/ui/card";
import cieloLogo from "@/assets/cielo-logo.png";
import siemensLogo from "@/assets/siemens-energy-logo.png";
import ambevLogo from "@/assets/ambev-logo.png";

const companyLogos: Record<string, string> = {
  "Cielo": cieloLogo,
  "Siemens Energy": siemensLogo,
  "Ambev": ambevLogo,
};

const experiences = [
  {
    company: "Cielo",
    role: "Estagiário em Produtos Bancários e Open Finance",
    period: "Julho 2025 – Atual",
    location: "Barueri, SP",
    description: "Atuo na área de Open Finance – Dados e Pagamentos, com foco no desenvolvimento e crescimento da base de consentimentos. Minha rotina envolve o acompanhamento e evolução de produtos que incentivam o opt-in de forma inteligente, conectando dados comportamentais a ofertas personalizadas. Sou responsável pela gestão analítica dos consentimentos, criando dashboards que monitoram a jornada do cliente e identificam padrões que orientam decisões estratégicas.\n\nAlém disso, atuo como Product Owner da vertical de integração dos produtos bancários dos bancos controladores (Bradesco e Banco do Brasil).",
    achievements: [
      "Desenvolvimento de novos produtos em Open Finance",
      "Construção de dashboards para análise de desempenho e jornada do cliente",
      "Atuação com ferramentas como Databricks, Amazon AWS, GitHub, Postman, Copilot Studio e pacote Office",
      "Relacionamento externo direto com representantes do Banco do Brasil, Bradesco e Alelo"
    ],
    color: "primary",
    isCurrent: true
  },
  {
    company: "Siemens Energy",
    role: "Estagiário de Desenvolvimento de Negócios",
    period: "Julho 2023 – Julho 2025",
    location: "São Paulo, SP",
    description: "Atuei na área de Desenvolvimento de Negócios por dois anos, realizando visitas comerciais a empresas dos setores de papel, celulose e fibra. Participei do back-office de projetos estratégicos, como Arauco 2 e Barcarena. Durante esse período, tive duas funções distintas que contribuíram significativamente para minha evolução profissional.\n\nComo Sales BA (Business Analytics), fui responsável pela preparação financeira das propostas comerciais, lidando com questões tributárias como ICMS, PIS/COFINS e ISS. Além disso, desenvolvi habilidades em planejamento estratégico e análise de mercado.",
    achievements: [
      "Análise de mercado e estudos de viabilidade",
      "Elaboração de propostas comerciais para projetos menores de service offshore",
      "Participação em projetos estratégicos de expansão",
      "Visitas presenciais a empresas do setor de papel e celulose",
      "Desenvolvimento de habilidades em planejamento estratégico"
    ],
    color: "secondary"
  },
  {
    company: "Ambev",
    role: "Jovem Aprendiz Financeiro",
    period: "Junho 2023 – Agosto 2023",
    location: "São Paulo, SP",
    description: "Minha primeira experiência profissional foi na unidade do Brooklyn, com foco em rotinas financeiras e apoio ao time de vendas. Essa vivência foi essencial para desenvolver responsabilidade, comunicação e trabalho em equipe.",
    achievements: [
      "Execução de rotinas financeiras",
      "Apoio ao time de vendas",
      "Desenvolvimento de responsabilidade e comunicação",
      "Fortalecimento do trabalho em equipe"
    ],
    color: "accent"
  }
];

const Experience = () => {
  const [visibleCards, setVisibleCards] = useState<boolean[]>(new Array(experiences.length).fill(false));
  const cardRefs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const observers = cardRefs.current.map((card, index) => {
      if (!card) return null;
      
      const observer = new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting && !visibleCards[index]) {
            setVisibleCards(prev => {
              const newState = [...prev];
              newState[index] = true;
              return newState;
            });
          }
        },
        { threshold: 0.1 }
      );
      
      observer.observe(card);
      return observer;
    });
    
    return () => {
      observers.forEach(observer => observer?.disconnect());
    };
  }, []);

  return (
    <section id="experiencias" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl md:text-5xl font-bold mb-16 text-center text-black">
          Minhas experiências profissionais
        </h2>
        
        <div className="max-w-6xl mx-auto relative">
          {experiences.map((exp, index) => (
            <div 
              key={index}
              ref={el => cardRefs.current[index] = el}
              className={`sticky transition-all duration-700 ${
                visibleCards[index] 
                  ? 'opacity-100 translate-y-0' 
                  : 'opacity-0 translate-y-8'
              }`}
              style={{
                top: `${100 + index * 40}px`,
                zIndex: index + 1,
              }}
            >
              <Card className="relative p-6 md:p-8 bg-card shadow-2xl hover:shadow-[0_25px_50px_-12px_rgba(0,0,0,0.35)] transition-all duration-300 ease-out min-h-[400px] flex flex-col group border border-border/50">
                {/* Badge "Atual" */}
                {exp.isCurrent && (
                  <div className="absolute top-4 right-4">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-primary text-white text-xs font-semibold shadow-lg animate-pulse">
                      <div className="w-2 h-2 bg-white rounded-full"></div>
                      Atual
                    </span>
                  </div>
                )}
                
                <div className="flex items-start gap-4 mb-4">
                  <div className="w-12 h-12 rounded-lg overflow-hidden bg-white flex items-center justify-center">
                    <img src={companyLogos[exp.company]} alt={`${exp.company} logo`} className="w-full h-full object-contain p-1" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-2xl font-bold text-foreground mb-1">{exp.company}</h3>
                    <p className="text-lg font-semibold text-muted-foreground mb-2">{exp.role}</p>
                    <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        {exp.period}
                      </span>
                      <span>📍 {exp.location}</span>
                    </div>
                  </div>
                </div>
                
                <p className="text-muted-foreground mb-4 leading-relaxed">
                  {exp.description}
                </p>
                
                <div className="space-y-2">
                  {exp.achievements.map((achievement, i) => (
                    <div key={i} className="flex items-start gap-2 group/item">
                      <CheckCircle2 className="w-5 h-5 flex-shrink-0 mt-0.5 text-green-500 transition-all duration-300 group-hover/item:scale-110" />
                      <span className="text-sm text-muted-foreground">{achievement}</span>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          ))}
          {/* Spacer para permitir scroll completo do último card */}
          <div className="h-[200px]"></div>
        </div>
      </div>
    </section>
  );
};

export default Experience;
