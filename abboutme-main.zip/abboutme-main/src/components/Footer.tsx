import { Linkedin, Mail, Phone, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const Footer = () => {
  const handleDownload = async (format: string) => {
    const fileNames: Record<string, string> = {
      PDF: "curriculo-joao-camargo.pdf",
      Word: "curriculo-joao-camargo.docx",
      TXT: "curriculo-joao-camargo.txt"
    };

    const fileName = fileNames[format];
    
    try {
      const { data } = supabase.storage
        .from("curriculos")
        .getPublicUrl(fileName);

      if (data?.publicUrl) {
        const link = document.createElement("a");
        link.href = data.publicUrl;
        link.download = fileName;
        link.target = "_blank";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        toast.success(`Download do currículo em ${format} iniciado!`);
      }
    } catch (error) {
      toast.error("Erro ao baixar o arquivo. Tente novamente.");
    }
  };

  return (
    <footer className="bg-card border-t border-border py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Download Section */}
          <div className="text-center mb-12 pb-12 border-b border-border">
            <h3 className="text-2xl font-bold mb-4 text-foreground">Download do Currículo</h3>
            <p className="text-muted-foreground mb-6">
              Baixe meu currículo completo nos formatos de sua preferência
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Button 
                onClick={() => handleDownload("PDF")}
                className="bg-gradient-primary hover:opacity-90"
              >
                <Download className="w-4 h-4 mr-2" />
                Download PDF
              </Button>
              <Button 
                onClick={() => handleDownload("Word")}
                variant="outline"
              >
                <Download className="w-4 h-4 mr-2" />
                Download Word
              </Button>
              <Button 
                onClick={() => handleDownload("TXT")}
                variant="outline"
              >
                <Download className="w-4 h-4 mr-2" />
                Download TXT
              </Button>
            </div>
          </div>
          
          {/* Social Links */}
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="text-center md:text-left">
              <h4 className="text-2xl font-bold text-black">
                João Camargo
              </h4>
            </div>
            
            <div className="flex gap-4">
              <a
                href="https://www.linkedin.com/in/joãorochacamargo"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 rounded-lg bg-primary/10 hover:bg-primary/20 transition-colors"
              >
                <Linkedin className="w-5 h-5 text-primary" />
              </a>
              <a
                href="mailto:joaovictorrochacamargo967@gmail.com"
                className="p-3 rounded-lg bg-primary/10 hover:bg-primary/20 transition-colors"
              >
                <Mail className="w-5 h-5 text-primary" />
              </a>
              <a
                href="tel:+5511932166197"
                className="p-3 rounded-lg bg-primary/10 hover:bg-primary/20 transition-colors"
              >
                <Phone className="w-5 h-5 text-primary" />
              </a>
            </div>
          </div>
          
          {/* Copyright */}
          <div className="mt-12 pt-8 border-t border-border text-center text-sm text-muted-foreground">
            <p>© 2025 João Camargo. Todos os direitos reservados.</p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
