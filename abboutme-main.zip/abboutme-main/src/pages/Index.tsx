import Header from "@/components/Header";
import AboutMe from "@/components/AboutMe";
import Experience from "@/components/Experience";
import Education from "@/components/Education";
import Contact from "@/components/Contact";
import CareerDevelopment from "@/components/CareerDevelopment";
import Footer from "@/components/Footer";
import ScrollProgress from "@/components/ScrollProgress";

const Index = () => {
  return (
    <div className="min-h-screen">
      <ScrollProgress />
      <Header />
      <AboutMe />
      <Education />
      <Experience />
      <CareerDevelopment />
      <Contact />
      <Footer />
    </div>
  );
};

export default Index;
