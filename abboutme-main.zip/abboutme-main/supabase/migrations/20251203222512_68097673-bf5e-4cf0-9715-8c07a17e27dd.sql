-- Criar bucket para currículos
INSERT INTO storage.buckets (id, name, public)
VALUES ('curriculos', 'curriculos', true);

-- Política para permitir download público (SELECT)
CREATE POLICY "Permitir download público de currículos"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'curriculos');