-- Create contacts table
CREATE TABLE public.contacts (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  message TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  read BOOLEAN DEFAULT FALSE
);

-- Enable Row Level Security
ALTER TABLE public.contacts ENABLE ROW LEVEL SECURITY;

-- Allow public inserts (anyone can submit the contact form)
CREATE POLICY "Allow public inserts" ON public.contacts
  FOR INSERT TO anon
  WITH CHECK (true);

-- Allow authenticated reads (you can view submitted messages)
CREATE POLICY "Allow authenticated reads" ON public.contacts
  FOR SELECT TO authenticated
  USING (true);

-- Allow authenticated updates (to mark as read)
CREATE POLICY "Allow authenticated updates" ON public.contacts
  FOR UPDATE TO authenticated
  USING (true);